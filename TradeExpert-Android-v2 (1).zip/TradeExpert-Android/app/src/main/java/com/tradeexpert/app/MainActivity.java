package com.tradeexpert.app;

import android.annotation.SuppressLint;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewClientCompat;

/**
 * Opens the live TradeExpert web app (tradeexpertea.com) inside a full-screen WebView.
 *
 * Links to the TradeExpert site and its Supabase backend stay inside the app. Everything
 * else (WhatsApp, email, other websites) opens in the phone's normal apps or browser.
 */
public class MainActivity extends ComponentActivity {

    /** Page the app opens first. Change this to point the app somewhere else. */
    private static final String START_URL = "https://tradeexpertea.com/ea-app/activate";

    private static final String SITE_HOST = "tradeexpertea.com";
    private static final String BACKEND_HOST = "zueqlxkqwigjlpgazeiz.supabase.co";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    /** Receives the result of a file picker opened by the web page (e.g. avatar or EA file upload). */
    private final ActivityResultLauncher<Intent> fileChooserLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK) {
                    results = WebChromeClient.FileChooserParams.parseResult(
                            result.getResultCode(), result.getData());
                }
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(results);
                    filePathCallback = null;
                }
            });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);        // the web app keeps session data in localStorage
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUserAgentString(settings.getUserAgentString() + " TradeExpertApp/1.0.0");

        // Keep the login session cookies, including ones set by the backend.
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new AppWebViewClient());
        webView.setWebChromeClient(new AppWebChromeClient());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }

        startBubbleSupport();
    }

    /** Starts the background service and asks for the permissions the bubble needs (once each). */
    private void startBubbleSupport() {
        SharedPreferences sp = getSharedPreferences("tx", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !sp.getBoolean("asked_notif", false)) {
            sp.edit().putBoolean("asked_notif", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!Settings.canDrawOverlays(this) && !sp.getBoolean("asked_overlay", false)) {
            sp.edit().putBoolean("asked_overlay", true).apply();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        startForegroundService(new Intent(this, BubbleService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        BubbleService.setAppVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        BubbleService.setAppVisible(false);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /** True for the TradeExpert site and its backend, which should open inside the app. */
    private static boolean isInternalHost(@Nullable String host) {
        if (host == null) return false;
        return host.equals(SITE_HOST)
                || host.endsWith("." + SITE_HOST)
                || host.equals(BACKEND_HOST);
    }

    private class AppWebViewClient extends WebViewClientCompat {

        @Override
        public boolean shouldOverrideUrlLoading(@NonNull WebView view, @NonNull WebResourceRequest request) {
            Uri uri = request.getUrl();
            String scheme = uri.getScheme();

            if (("https".equals(scheme) || "http".equals(scheme)) && isInternalHost(uri.getHost())) {
                return false; // load inside the app
            }
            return openExternally(uri);
        }

        @Override
        public void onReceivedError(@NonNull WebView view, @NonNull WebResourceRequest request,
                                    @NonNull WebResourceError error) {
            if (request.isForMainFrame()) {
                view.loadData(
                        "<html><body style='font-family:sans-serif;background:#0A0D14;color:#fff;" +
                        "text-align:center;padding:48px 16px'>" +
                        "<h2>Can't reach TradeExpert</h2>" +
                        "<p>Check your internet connection, then tap Retry.</p>" +
                        "<p><a style='color:#3B82F6' href='" + START_URL + "'>Retry</a></p>" +
                        "</body></html>",
                        "text/html", "UTF-8");
            }
        }
    }

    private class AppWebChromeClient extends WebChromeClient {

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;
            try {
                fileChooserLauncher.launch(params.createIntent());
                return true;
            } catch (ActivityNotFoundException e) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
                return false;
            }
        }
    }

    private boolean openExternally(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }
}
