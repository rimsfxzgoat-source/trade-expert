# TradeExpert Android

Android app that opens the live TradeExpert web app (`https://tradeexpertea.com/ea-app/activate`)
in a full-screen WebView. Web updates go live on the site without a new APK.

## Build

1. Install Android Studio (Ladybug or newer). It includes the JDK and SDK manager.
2. **File → Open** and choose this folder.
3. Let Gradle sync. Android Studio installs SDK 35 and the dependencies.
4. Press **Run ▶** on a phone or emulator (Android 7.0 / API 24 or newer).
5. For a release build: **Build → Generate Signed App Bundle / APK**.

Debug APK from the command line, once the Gradle wrapper is generated:

```
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

## Project layout

| Path | Purpose |
| --- | --- |
| `app/src/main/java/com/tradeexpert/app/MainActivity.java` | WebView host: loads the site, keeps site links in the app, opens other links externally, file uploads, offline message, back button |
| `app/src/main/AndroidManifest.xml` | Internet permission and launcher activity |
| `app/src/main/res/` | App name, colours, theme, placeholder launcher icon |
| `app/build.gradle` | Package `com.tradeexpert.app`, SDK versions, dependencies |

To change the start page, edit `START_URL` in `MainActivity.java`.

## What stays inside the app

- `tradeexpertea.com` and its subdomains
- The Supabase backend (`zueqlxkqwigjlpgazeiz.supabase.co`), so logins and API calls work

Everything else (WhatsApp `wa.me` links, email, other websites) opens in the phone's own app or browser.

## Known limits

- **Sign-in with Google.** Google blocks OAuth inside embedded WebViews. Email and password
  login works. Google sign-in needs Chrome Custom Tabs or a native SDK.
- **Sign-in return links.** Email confirmation and password reset links open in the phone's
  browser, not the app, unless the site uses an app link (Android App Links with a
  `assetlinks.json` file on `tradeexpertea.com`).
- **Push notifications** (`push_subscriptions`) need Firebase Cloud Messaging. Not included.
- **App icon** is a placeholder. Replace `drawable/ic_launcher_foreground.xml` with the TradeExpert logo.
- **Not compiled in the build environment.** It has not been built yet, so expect small fixes on first sync.
